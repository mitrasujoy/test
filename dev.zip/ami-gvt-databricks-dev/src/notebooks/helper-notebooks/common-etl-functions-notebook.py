# Databricks notebook source
import logging
import json
from datetime import datetime

# COMMAND ----------

class DataLoadFunctions:
    def __init__(self, spark):
        self.spark = spark
    
    def load_stream_data(self, read_format, config, path):
        df = self.spark.readStream.format(read_format).options(**config).load(path)
        return df 
    
    def read_config(self, path):
        df = self.spark.read.option("multiline", "true").json(path)
        jsn = json.loads(df.toJSON().first())
        return jsn

if __name__ == "__main__":
    logging.basicConfig()
    logger = logging.getLogger("common_etl_functions")
    logger.setLevel(logging.INFO)
    dataLoad = DataLoadFunctions(spark)
    logger.info(f"{datetime.now()}: ETL functions")
