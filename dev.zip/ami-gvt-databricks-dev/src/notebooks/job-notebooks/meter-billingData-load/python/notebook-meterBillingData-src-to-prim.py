# Databricks notebook source
# MAGIC %run ./common-etl-functions-notebook

# COMMAND ----------

from pyspark.sql.functions import * 
from pyspark.sql.types import *
from datetime import datetime
import time
from pyspark.sql import functions as func
import json
import logging
import boto3

# COMMAND ----------

if __name__ == "__main__":
    logging.basicConfig()
    logger = logging.getLogger("Meter_Data_Primary")
    logger.setLevel(logging.INFO)
    config_loc = dbutils.widgets.get("config_loc")
    env = dbutils.widgets.get("env")
    env_id = dbutils.widgets.get("env_id")
    meter_billing_srs_table = dbutils.widgets.get("meter_billing_srs_table")
    meter_billing_15_min_gran_table = dbutils.widgets.get("meter_billing_15_min_gran_table")
    last_ingestion_config = dbutils.widgets.get("last_ingestion_config")
    meter_billing_land_table = dbutils.widgets.get("meter_billing_land_table")

    config_loc = config_loc.format(env_id)
    try:
        dict_job_run_metadata = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
        currentRunId = str(dict_job_run_metadata['currentRunId']['id'])
        logger.info(f"{datetime.now()}: Run id - {currentRunId}")
        # parsing config json
        # config_json = lc(spark).read_config(config_loc)
        config_json = DataLoadFunctions(spark).read_config(config_loc)
        logger.info(f"{datetime.now()}: Fetched configuration from - {config_loc}")
        # initializing variables
        core_catalog = config_json['tiers']['core']['catalog'].format(env)
        core_schema = config_json['tiers']['core']['schema']
        lnd_catalog = config_json['tiers']['land']['catalog'].format(env)
        lnd_schema = config_json['tiers']['land']['schema']

        cnt = spark.table(f"{lnd_catalog}.{lnd_schema}.{meter_billing_land_table}").count()
        logger.info(f"{datetime.now()}: Row count in {lnd_catalog}.{lnd_schema}.{meter_billing_land_table} - {cnt}")
        if cnt > 0:
            # getting max_id from prim table before ingestion. This value will the stored in last_ingestion_config table 
            query_1 = f"""select max_id from {core_catalog}.{core_schema}.{last_ingestion_config} 
            where table_name = '{meter_billing_srs_table}'
            order by id desc"""
            id_from_src = spark.sql(query_1).collect()[0][0]
            
            srs_df = spark.read.table(f"{core_catalog}.{core_schema}.{meter_billing_srs_table}")

            srs_df = srs_df.select('id', 'service_point_id', 'interval_reading_ts', 'value', 'channel_number')\
                .filter("id > {}".format(id_from_src))   
                    
            #list_of_incoming_channels = [i for i in srs_df.select('channel_number').distinct().rdd.collect()]
            #list_of_billing_channels = [1, 2, 3, 4]
            #channels_to_add = [i for i in list_of_billing_channels if i not in list_of_incoming_channels]
            srs_df = srs_df.groupBy('service_point_id', 'interval_reading_ts')\
                .pivot('channel_number')\
                .agg(first('value'))\
                .withColumn('run_id', lit(currentRunId))\
                .withColumnRenamed('1', 'kwh_delivered')\
                .withColumnRenamed('2', 'kwh_received')\
                .withColumnRenamed('3', 'kvarh_delivered')\
                .withColumnRenamed('4', 'kvarh_received')\
                .withColumn("created_date", current_date())
            prim_df = spark.read.table(f"{core_catalog}.{core_schema}.{meter_billing_15_min_gran_table}")
            max_prim_id = prim_df.select(max(col("id")).alias('max_id')).collect()[0][0]
            if max_prim_id == None:
                max_prim_id = 0
            logger.info(f"{datetime.now()}: max_id - '{max_prim_id}'")
            insert_stmt = f"""insert into {core_catalog}.{core_schema}.{last_ingestion_config}
            (run_id, table_name, max_id, created_at)
            values ('{currentRunId}', '{meter_billing_15_min_gran_table}', {max_prim_id}, current_timestamp())"""
            logger.info(f"{datetime.now()}: Executing - {insert_stmt}")
            spark.sql(insert_stmt)

            srs_df.select('run_id', 'service_point_id', 'interval_reading_ts', 'kwh_delivered', 'kwh_received', 'kvarh_delivered'
                        , 'kvarh_received', 'created_date')\
                            .write.format('delta')\
                                .mode('append')\
                                    .saveAsTable(f'{core_catalog}.{core_schema}.{meter_billing_15_min_gran_table}')
            logger.info(f"{datetime.now()}: Data is loaded in {core_catalog}.{core_schema}.{meter_billing_15_min_gran_table}")
            cnt = spark.table(f"{core_catalog}.{core_schema}.{meter_billing_15_min_gran_table}").count()
            logger.info(f"{datetime.now()}: Final data count = {cnt}")
        else:
            logger.info(f"{datetime.now()}: No data to process")
    except Exception as err:
        raise Exception("Error in running job: " + err.__str__())
