# Databricks notebook source
# MAGIC %run ./common-etl-functions-notebook

# COMMAND ----------

from pyspark.sql.functions import * 
from pyspark.sql.types import *
from datetime import datetime
import time
from pyspark.sql import functions as func
import json
import logging
import boto3

# COMMAND ----------

# from pyspark import SparkConf, SparkContext
# Create a new Spark configuration
# conf = SparkConf()
# conf.set("spark.driver.extraJavaOptions", "-Dpy4j.security.allowed.methods=com.databricks.backend.common.rpc.CommandContext.toJson")
# sc = SparkContext(conf=conf)

# COMMAND ----------

class JobFunctions:
    def __init__(self, spark):
        self.spark = spark
    
    def get_dir_content(self, ls_path):
        dir_paths = dbutils.fs.ls(ls_path)
        subdir_paths = [self.get_dir_content(p.path) for p in dir_paths if p.isDir() and p.path != ls_path]
        flat_subdir_paths = [p for subdir in subdir_paths for p in subdir]
        return list(map(lambda p: p.path, dir_paths)) + flat_subdir_paths

# COMMAND ----------

if __name__ == "__main__":
    logging.basicConfig()
    logger = logging.getLogger("Meter_Data_Raw")
    logger.setLevel(logging.INFO)
    config_loc = dbutils.widgets.get("config_loc")
    env = dbutils.widgets.get("env")
    env_id = dbutils.widgets.get("env_id") # 'ndl'
    meter_billing_land_table = dbutils.widgets.get("meter_billing_land_table")
    intervals_to_consider = dbutils.widgets.get("intervals_to_consider") # add minute
    
    config_loc = config_loc.format(env_id)
    try:
        job_func = JobFunctions(spark)
        dict_job_run_metadata = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
        currentRunId = str(dict_job_run_metadata['currentRunId']['id'])
        logger.info(f"{datetime.now()}: Run id - {currentRunId}")
        # parsing config json
        # config_json = lc(spark).read_config(config_loc)
        config_json = DataLoadFunctions(spark).read_config(config_loc)
        
        logger.info(f"{datetime.now()}: Fetched configuration from - {config_loc}")
        # initializing variables
        bl_src_bucket = config_json['asset_category']['meter']['billing']['source_bucket'].format(env_id)
        bl_src_path = f"s3a://{bl_src_bucket}/{config_json['asset_category']['meter']['billing']['source_key']}"

        bl_checkpoint = config_json['asset_category']['meter']['billing']['checkpoint'].format(env_id)
        bl_schema_loc = config_json['asset_category']['meter']['billing']['schema_location'].format(env_id)
        lnd_catalog = config_json['tiers']['land']['catalog'].format(env)
        lnd_schema = config_json['tiers']['land']['schema']
        bl_schm_hnt = config_json['asset_category']['meter']['billing']['schema_hints']
        list_of_intervals = [i.strip() for i in intervals_to_consider.split(',')]

        variable = {"billing_data_source_path": bl_src_path,
                    "land_catalog": lnd_catalog,
                    "land_schema": lnd_schema,
                    "meter_billing_land_table": meter_billing_land_table}
        logger.info(f"{datetime.now()}: Variables are initialized for ETL - {variable}")
        cnt = spark.table(f"{lnd_catalog}.{lnd_schema}.{meter_billing_land_table}").count()
        logger.info(f"{datetime.now()}: Data count before loading in {lnd_catalog}.{lnd_schema}.{meter_billing_land_table} = {cnt}")
        # first load the data into SRS table then truncate
        # hist_df = spark.sql(f"select * from {lnd_catalog}.{lnd_schema}.{meter_billing_land_table}")
        paths = job_func.get_dir_content(bl_src_path)
        obj = [p for p in paths]
        if len(obj) > 0:
            cloud_file_config = {
                "cloudFiles.format": dbutils.widgets.get('cloud_file_format')
                , "header": eval(dbutils.widgets.get('file_header'))
                , "cloudFiles.backfillInterval": dbutils.widgets.get('backfill_interval')
                , "cloudFiles.fetchParallelism": int(dbutils.widgets.get('fetch_parallelism'))
                , "ignoreLeadingWhiteSpace": eval(dbutils.widgets.get('ignore_leading_whitespace'))
                , "ignoreTrailingWhiteSpace": eval(dbutils.widgets.get('ignore_trailing_whitespace'))
                , "ignoreMissingFiles": eval(dbutils.widgets.get('ignore_missing_files'))
                , "multiLine": eval(dbutils.widgets.get('multiline'))
                , "delimiter": dbutils.widgets.get('file_delimiter')
                , "cloudFiles.schemaLocation": bl_schema_loc
                , "cloudFiles.schemaHints": bl_schm_hnt
            }
            # df = dlf(spark).load_stream_data("cloudFiles", cloud_file_config, bl_src_path)
            df = DataLoadFunctions(spark).load_stream_data("cloudFiles", cloud_file_config, bl_src_path)
            df = df.select('ServiceDeliveryPoint', 'IntervalBlockIntervalreadingsReadingTypeRef', 
                           'IntervalReadingValue', 'IntervalReadingTimestamp', 'ReadingTypeChannelNumber', 'NumberIntervals')\
                               .filter(col('IntervalBlockIntervalreadingsReadingTypeRef').isin(list_of_intervals))
            logger.info(f"{datetime.now()}: Read billing data for channel 1, 2, 3, 4")
            # Truncate land table before ingestion
            spark.sql(f"truncate table {lnd_catalog}.{lnd_schema}.{meter_billing_land_table}")
            logger.info(f"{datetime.now()}: Table is truncated")
            df = df.withColumnsRenamed({'ServiceDeliveryPoint': 'service_point_id'
                                        , 'IntervalBlockIntervalreadingsReadingTypeRef': 'interval_min'
                                        , 'IntervalReadingTimestamp': 'interval_reading_ts'
                                        , 'IntervalReadingValue': 'value'
                                        , 'ReadingTypeChannelNumber': 'channel_number'})\
                .withColumn('run_id', lit(currentRunId)) \
                .withColumn('read_quality', lit('RAW'))\
                .withColumn("source_file_name", input_file_name())\
                .withColumn("created_at", current_timestamp())
            df = df.select('run_id', 'service_point_id', 'interval_min', 'interval_reading_ts', 'value', 'channel_number', 'read_quality', 'source_file_name', 'created_at') # '_rescued_data',
            df.writeStream.trigger(availableNow=True)\
                .option("checkpointLocation", bl_checkpoint)\
                    .option('mergeSchema', True)\
                        .toTable(f"{lnd_catalog}.{lnd_schema}.{meter_billing_land_table}")\
                            .awaitTermination()
            logger.info(f"{datetime.now()}: Data is written to {lnd_catalog}.{lnd_schema}.{meter_billing_land_table}")
            cnt = spark.table(f"{lnd_catalog}.{lnd_schema}.{meter_billing_land_table}").count()
            logger.info(f"{datetime.now()}: Row count - {cnt}")
        else:
            logger.warning(f"{datetime.now()}: No files to process")
    except Exception as err:
        raise Exception("Error in running job: " + err.__str__())
