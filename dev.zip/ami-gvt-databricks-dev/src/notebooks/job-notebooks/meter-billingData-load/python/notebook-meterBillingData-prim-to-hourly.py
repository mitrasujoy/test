# Databricks notebook source
# MAGIC %run ./common-etl-functions-notebook

# COMMAND ----------

from pyspark.sql.functions import * 
from pyspark.sql.types import *
from datetime import datetime
import time
from pyspark.sql import functions as func
import json
import logging
import boto3

# COMMAND ----------

if __name__ == "__main__":
    logging.basicConfig()
    logger = logging.getLogger("Meter_Data_Raw")
    logger.setLevel(logging.INFO)
    try:
        config_loc = dbutils.widgets.get("config_loc")
        env = dbutils.widgets.get("env")
        env_id = dbutils.widgets.get("env_id")
        meter_billing_15_min_gran_table = dbutils.widgets.get("meter_billing_15_min_gran_table")
        last_ingestion_config = dbutils.widgets.get("last_ingestion_config_table")
        meter_billing_hourly_gran_table = dbutils.widgets.get("meter_billing_hourly_gran_table")
        meter_billing_land_table = dbutils.widgets.get("meter_billing_land_table")
        config_loc = config_loc.format(env_id)
        dict_job_run_metadata = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
        currentRunId = str(dict_job_run_metadata['currentRunId']['id'])
        logger.info(f"{datetime.now()}: Run id - {currentRunId}")
        
        # config_json = lc(spark).read_config(config_loc)
        config_json = DataLoadFunctions(spark).read_config(config_loc)
        logger.info(f"{datetime.now()}: Fetched configuration from - {config_loc}")
        core_catalog = config_json['tiers']['core']['catalog'].format(env)
        core_schema = config_json['tiers']['core']['schema']
        lnd_catalog = config_json['tiers']['land']['catalog'].format(env)
        lnd_schema = config_json['tiers']['land']['schema']

        cnt = spark.table(f"{lnd_catalog}.{lnd_schema}.{meter_billing_land_table}").count()
        logger.info(f"{datetime.now()}: Row count in {lnd_catalog}.{lnd_schema}.{meter_billing_land_table} - {cnt}")
        if cnt > 0:
            # getting max_id from prim table before ingestion. This value will the stored in last_ingestion_config table 
            query_1 = f"""select max_id from {core_catalog}.{core_schema}.{last_ingestion_config} 
            where table_name = '{meter_billing_15_min_gran_table}'
            order by id desc"""
            id_from_prim = spark.sql(query_1).collect()[0][0]
            logger.info(f"{datetime.now()}: max id before ingestion - {id_from_prim}")
            # reading incremental data from prim table 
            time_format = "yyyy-MM-dd'T'HH:mm:ss.SSSz"
            query_2 = f"""select 
            '{currentRunId}' as run_id
            , service_point_id
            , date(interval_reading_ts_local - INTERVAL 1 minutes) as interval_reading_date
            , hour(interval_reading_ts_local - INTERVAL 1 minutes) interval_reading_hour
            , round(nvl(sum(kwh_delivered), 0), 3) as kwh_delivered
            , round(nvl(sum(kwh_received), 0), 3) as kwh_received
            , round(nvl(sum(kwh_net), 0), 3) as kwh_net
            , round(nvl(sum(kvarh_delivered), 0), 3) as kvarh_delivered
            , round(sum(kvarh_received), 3) as kvarh_received
            , round(sum(kvarh_net), 3) as kvarh_net
            , round(sum(kw_delivered), 3) as kw_delivered
            , round(sum(kw_received), 3) as kw_received
            , round(sum(kw_net), 3) as kw_net
            , round(sum(kvar_delivered), 3) as kvar_delivered
            , round(sum(kvar_received), 3) as kvar_received
            , round(sum(kvar_net), 3) as kvar_net
            , round(sum(kva_delivered), 3) as kva_delivered
            , round(sum(kva_received), 3) as kva_received
            , round(sum(kva_net), 3) as kva_net
            , round(sum(pf_delivered), 3) as pf_delivered
            , round(sum(pf_received), 3) as pf_received
            from 
            (select *
            , from_utc_timestamp(to_timestamp(interval_reading_ts, "{time_format}"), concat('UTC',substring(interval_reading_ts, -6))) as interval_reading_ts_local
            from {core_catalog}.{core_schema}.{meter_billing_15_min_gran_table})
            where id > {id_from_prim}
            group by service_point_id, interval_reading_date, interval_reading_hour
            order by interval_reading_date, interval_reading_hour
            """
            prim_df = spark.sql(query_2).withColumn('created_date', current_date()).persist()
            prim_df.write.format('delta')\
                            .mode('append')\
                            .saveAsTable(f'{core_catalog}.{core_schema}.{meter_billing_hourly_gran_table}')
            prim_df.unpersist()
        else:
            logger.info(f"{datetime.now()}: No data to process")
    except Exception as err:
        raise Exception("Error in running job: " + err.__str__())
