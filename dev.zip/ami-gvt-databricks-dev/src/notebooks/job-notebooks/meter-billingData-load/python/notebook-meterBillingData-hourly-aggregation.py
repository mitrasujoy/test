# Databricks notebook source
# MAGIC %run ./common-etl-functions-notebook 

# COMMAND ----------

from pyspark.sql.functions import * 
from pyspark.sql.types import *
from datetime import datetime
import time
from pyspark.sql import functions as func
import json
import logging
import boto3

# COMMAND ----------

if __name__ == "__main__":
    logging.basicConfig()
    logger = logging.getLogger("Meter_Data_Hourly_Aggregation")
    logger.setLevel(logging.INFO)
    try:
        config_loc = dbutils.widgets.get("config_loc")
        env = dbutils.widgets.get("env")
        env_id = dbutils.widgets.get("env_id")
        last_ingestion_config = dbutils.widgets.get("last_ingestion_config_table")
        meter_billing_15_min_gran_table = dbutils.widgets.get("meter_billing_15_min_gran_table")
        meter_billing_aggr_hourly_gran_table = dbutils.widgets.get("meter_billing_aggr_hourly_gran_table")
        meter_billing_land_table = dbutils.widgets.get("meter_billing_land_table")
        config_loc = config_loc.format(env_id)
        dict_job_run_metadata = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
        currentRunId = str(dict_job_run_metadata['currentRunId']['id'])
        logger.info(f"{datetime.now()}: Run id - {currentRunId}")
        
        config_json = DataLoadFunctions(spark).read_config(config_loc)
        logger.info(f"{datetime.now()}: Fetched configuration from - {config_loc}")
        core_catalog = config_json['tiers']['core']['catalog'].format(env)
        core_schema = config_json['tiers']['core']['schema']
        lnd_catalog = config_json['tiers']['land']['catalog'].format(env)
        lnd_schema = config_json['tiers']['land']['schema']

        cnt = spark.table(f"{lnd_catalog}.{lnd_schema}.{meter_billing_land_table}").count()
        logger.info(f"{datetime.now()}: Row count in {lnd_catalog}.{lnd_schema}.{meter_billing_land_table} - {cnt}")

        if cnt > 0:
            # getting max_id from prim table before ingestion. This value will the stored in last_ingestion_config table 
            query_1 = f"""select max_id from {core_catalog}.{core_schema}.{last_ingestion_config} 
            where table_name = '{meter_billing_15_min_gran_table}'
            order by id desc"""
            id_from_prim = spark.sql(query_1).collect()[0][0]
            logger.info(f"{datetime.now()}: max id before ingestion - {id_from_prim}")

            # reading incremental data from prim table 
            time_format = "yyyy-MM-dd'T'HH:mm:ss.SSSz"

            query_2 = f"""
            with t1
            as (
            select *
            , from_utc_timestamp(to_timestamp(interval_reading_ts, "{time_format}")
            , concat('UTC',substring(interval_reading_ts, -6))) as interval_reading_ts_local 
            from {core_catalog}.{core_schema}.{meter_billing_15_min_gran_table}
            where id > {id_from_prim}
            ),
            t2 as (
            select service_point_id
            , date(interval_reading_ts_local - INTERVAL 1 minutes) as interval_reading_date
            , hour(interval_reading_ts_local - INTERVAL 1 minutes) interval_reading_hour
            , * from t1
            ),
            t3 as (
            select *,
            count(*) over (partition by service_point_id, interval_reading_date, interval_reading_hour 
            order by interval_reading_date) as cnt
            from t2
            )
            select 
            '{currentRunId}' as run_id
            , service_point_id
            , interval_reading_date
            , interval_reading_hour
            , min(kwh_delivered) as kwh_delivered_min
            , max(kwh_delivered) as kwh_delivered_max
            , round(sqrt(sum(pow(kwh_delivered, 2)/cnt)), 3) as kwh_delivered_rms
            , min(kwh_received) as kwh_received_min
            , max(kwh_received) as kwh_received_max
            , round(sqrt(sum(pow(kwh_received, 2)/cnt)), 3) as kwh_received_rms
            , min(kwh_net) as kwh_net_min
            , max(kwh_net) as kwh_net_max
            , round(sqrt(sum(pow(kwh_net, 2)/cnt)), 3) as kwh_net_rms
            , min(kvarh_delivered) as kvarh_delivered_min
            , max(kvarh_delivered) as kvarh_delivered_max
            , round(sqrt(sum(pow(kvarh_delivered, 2)/cnt)), 3) as kvarh_delivered_rms
            , min(kvarh_received) as kvarh_received_min
            , max(kvarh_received) as kvarh_received_max
            , round(sqrt(sum(pow(kvarh_received, 2)/cnt)), 3) as kvarh_received_rms
            , min(kvarh_net) as kvarh_net_min
            , max(kvarh_net) as kvarh_net_max
            , round(sqrt(sum(pow(kvarh_net, 2)/cnt)), 3) as kvarh_net_rms
            , min(kw_delivered) as kw_delivered_min
            , max(kw_delivered) as kw_delivered_max
            , round(sqrt(sum(pow(kw_delivered, 2)/cnt)), 3) as kw_delivered_rms
            , min(kw_received) as kw_received_min
            , max(kw_received) as kw_received_max
            , round(sqrt(sum(pow(kw_delivered, 2)/cnt)), 3) as kw_received_rms
            , min(kw_net) as kw_net_min
            , max(kw_net) as kw_net_max
            , round(sqrt(sum(pow(kw_net, 2)/cnt)), 3) as kw_net_rms
            , min(kvar_delivered) as kvar_delivered_min
            , max(kvar_delivered) as kvar_delivered_max
            , round(sqrt(sum(pow(kvar_delivered, 2)/cnt)), 3) as kvar_delivered_rms
            , min(kvar_received) as kvar_received_min
            , max(kvar_received) as kvar_received_max
            , round(sqrt(sum(pow(kvar_received, 2)/cnt)), 3) as kvar_received_rms
            , min(kvar_net) as kvar_net_min
            , max(kvar_net) as kvar_net_max
            , round(sqrt(sum(pow(kvar_net, 2)/cnt)), 3) as kvar_net_rms
            , min(kva_delivered) as kva_delivered_min
            , max(kva_delivered) as kva_delivered_max
            , round(sqrt(sum(pow(kva_delivered, 2)/cnt)), 3) as kva_delivered_rms
            , min(kva_received) as kva_received_min
            , max(kva_received) as kva_received_max
            , round(sqrt(sum(pow(kva_received, 2)/cnt)), 3) as kva_received_rms
            , min(kva_net) as kva_net_min
            , max(kva_net) as kva_net_max
            , round(sqrt(sum(pow(kva_net, 2)/cnt)), 3) as kva_net_rms
            , min(pf_delivered) as pf_delivered_min
            , max(pf_delivered) as pf_delivered_max
            , round(sqrt(sum(pow(pf_delivered, 2)/cnt)), 3) as pf_delivered_rms
            , min(pf_received) as pf_received_min
            , max(pf_received) as pf_received_max
            , round(sqrt(sum(pow(pf_received, 2)/cnt)), 3) as pf_received_rms
            from t3
            group by service_point_id, interval_reading_date, interval_reading_hour
            order by service_point_id, interval_reading_date, interval_reading_hour
            """
            prim_df = spark.sql(query_2).withColumn('created_date', current_date()).persist()
            prim_df.write.format('delta')\
                            .mode('append')\
                            .saveAsTable(f'{core_catalog}.{core_schema}.{meter_billing_aggr_hourly_gran_table}')
            prim_df.unpersist()
        else:
            logger.info(f"{datetime.now()}: No data to process")
    except Exception as err:
            raise Exception("Error in running job: " + err.__str__())
