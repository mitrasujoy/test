# Databricks notebook source
# MAGIC %run ./common-etl-functions-notebook

# COMMAND ----------

from pyspark.sql.functions import * 
from pyspark.sql.types import *
from datetime import datetime
import time
from pyspark.sql import functions as func
import json
import logging
import boto3

# COMMAND ----------

if __name__ == "__main__":
    logging.basicConfig()
    logger = logging.getLogger("Meter_Data_SRS")
    logger.setLevel(logging.INFO)
    config_loc = dbutils.widgets.get("config_loc")
    env = dbutils.widgets.get("env")
    env_id = dbutils.widgets.get("env_id")
    meter_billing_land_table = dbutils.widgets.get("meter_billing_land_table")
    meter_billing_srs_table = dbutils.widgets.get("meter_billing_srs_table")
    last_ingestion_tracker = dbutils.widgets.get("last_ingestion_config")
    config_loc = config_loc.format(env_id)
    try:
        dict_job_run_metadata = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
        currentRunId = str(dict_job_run_metadata['currentRunId']['id'])
        logger.info(f"{datetime.now()}: Run id - {currentRunId}")
        # parsing config json
        # config_json = lc(spark).read_config(config_loc)
        config_json = DataLoadFunctions(spark).read_config(config_loc)
        logger.info(f"{datetime.now()}: Fetched configuration from - {config_loc}")

        # initializing variables
        lnd_catalog = config_json['tiers']['land']['catalog'].format(env)
        lnd_schema = config_json['tiers']['land']['schema']
        core_catalog = config_json['tiers']['core']['catalog'].format(env)
        core_schema = config_json['tiers']['core']['schema']
        
        cnt = spark.table(f"{lnd_catalog}.{lnd_schema}.{meter_billing_land_table}").count()
        logger.info(f"{datetime.now()}: Row count in {lnd_catalog}.{lnd_schema}.{meter_billing_land_table} - {cnt}")
        if cnt > 0:
            # Load data to SRS table
            # Select max id before loading the data
            srs_df = spark.read.table(f"{core_catalog}.{core_schema}.{meter_billing_srs_table}")
            max_id = srs_df.select(max(col("id")).alias('max_id')).collect()[0][0]
            if max_id == None:
                max_id = 0
            logger.info(f"{datetime.now()}: max_id - '{max_id}'")
            # Handle data duplication
            # Reading data from Land table
            raw_df = spark.read.table(f"{lnd_catalog}.{lnd_schema}.{meter_billing_land_table}")\
                .drop(*('run_id'))\
                .withColumn('run_id', lit(currentRunId))\
                .withColumn("created_date", current_date()).persist()
            raw_df = raw_df.select('run_id', 'service_point_id', 'interval_min', 'interval_reading_ts',
                                    'value', 'channel_number', 'read_quality', 'source_file_name', 'created_date')
            raw_df.write.format('delta')\
                .mode('append')\
                    .option('mergeSchema', True)\
                        .saveAsTable(f'{core_catalog}.{core_schema}.{meter_billing_srs_table}')
            cnt = spark.table(f"{core_catalog}.{core_schema}.{meter_billing_srs_table}").count()
            logger.info(f"{datetime.now()}: Final data count in {core_catalog}.{core_schema}.{meter_billing_srs_table} = {cnt}")
            # writting max id before ingestion to last ingestion config table
            insert_stmt = f"""insert into {core_catalog}.{core_schema}.{last_ingestion_tracker}
                (run_id, table_name, max_id, created_at)
                values ('{currentRunId}', '{meter_billing_srs_table}', {max_id}, current_timestamp())"""
            logger.info(f"{datetime.now()}: Executing - {insert_stmt}")
            spark.sql(insert_stmt)
            logger.info(f"{datetime.now()}: Last ingestion config has been updated for {meter_billing_srs_table}")
        else:
            logger.info(f"{datetime.now()}: No data to process")
    except Exception as err:
        raise Exception("Error in running job: " + err.__str__())
