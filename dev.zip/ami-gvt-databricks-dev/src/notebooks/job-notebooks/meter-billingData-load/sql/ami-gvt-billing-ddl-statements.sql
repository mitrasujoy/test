-- Databricks notebook source
-- drop table if exists dev_landing_zone.mdl.meter_billing_raw;
CREATE TABLE if not exists dev_landing_zone.mdl.meter_billing_raw
(run_id string,
`id` bigint generated always as identity, 
service_point_id string,
 interval_min string,
 interval_reading_ts string,
 value double,
 channel_number string,
 read_quality string,
 _rescued_data string,
 source_file_name string,
 created_at timestamp
 )
 PARTITIONED BY (channel_number)
 LOCATION 's3a://ndl-us-east-1-s3-xe-dbxext/land/meter_billing_raw';

-- COMMAND ----------

-- drop table if exists dev_core_zone.mdl.meter_billing_src;
CREATE TABLE if not exists dev_core_zone.mdl.meter_billing_src
(
run_id string,
`id` bigint generated always as identity, 
service_point_id string,
interval_min string,
interval_reading_ts string,
value double,
channel_number string,
read_quality string,
source_file_name string,
created_date date
 )PARTITIONED BY (channel_number, created_date)
 LOCATION 's3a://ndl-us-east-1-s3-xe-dbxext/core/meter_billing_src';

-- COMMAND ----------


-- drop table if exists dev_core_zone.mdl.meter_granular_15_min_billing_loading;
CREATE TABLE if not exists dev_core_zone.mdl.meter_granular_15_min_billing_loading
(
run_id string,
`id` bigint generated always as identity, 
service_point_id string,
interval_reading_ts string,
kwh_delivered double,
kwh_received double,
kvarh_delivered double,
kvarh_received double,
kwh_net double generated always as (cast(round(nvl((kwh_delivered - kwh_received), 0), 2) as double)) comment 'calculated field',
kvarh_net double generated always as (cast(round(nvl((kvarh_delivered - kvarh_received), 0), 2) as double)) comment 'calculated field',
kw_delivered double generated always as (cast(round(nvl((kwh_delivered/0.25), 0), 2) as double)) comment 'calculated field',
kw_received double generated always as (cast(round(nvl((kwh_received/0.25), 0), 2) as double)) comment 'calculated field',
kvar_delivered double generated always as (cast(round(nvl((kvarh_delivered/0.25), 0), 2) as double)) comment 'calculated field',
kvar_received double generated always as (cast(round(nvl((kvarh_received/0.25), 0), 2) as double)) comment 'calculated field',
kw_net double generated always as (cast(round(nvl(((kwh_delivered/0.25) - (kwh_received/0.25)), 0), 3) as double)) comment 'calculated field',
kvar_net double generated always as (cast(round(nvl(((kvarh_delivered/0.25) - (kvarh_received/0.25)), 0), 3) as double)) comment 'calculated field',
kva_delivered double generated always as (cast(round(nvl((sqrt(pow((kwh_delivered/0.25), 2) + pow((kvarh_delivered/0.25), 2))), 0) ,2) as double)) comment 'calculated field',
kva_received double generated always as (cast(round(nvl((sqrt(pow((kwh_received/0.25), 2) + pow((kvarh_received/0.25), 2))), 0) ,2) as double)) comment 'calculated field',
kva_net double generated always as (cast(round(nvl(((sqrt(pow((kwh_delivered/0.25), 2) + pow((kvarh_delivered/0.25), 2))) - (sqrt(pow((kwh_received/0.25), 2) + pow((kvarh_received/0.25), 2)))), 0), 3) as double)) comment 'calculated field',
pf_delivered double generated always as (cast(round(nvl((kwh_delivered/sqrt(pow(kwh_delivered, 2) + pow(kvarh_delivered, 2))), 0), 2) as double)) comment 'calculated field',
pf_received double generated always as (cast(round(nvl((kwh_received/sqrt(pow(kwh_received, 2) + pow(kvarh_received, 2))), 0), 2) as double)) comment 'calculated field',
created_date date
 )
 PARTITIONED BY (created_date)
 LOCATION 's3a://ndl-us-east-1-s3-xe-dbxext/core/meter_granular_15_min_billing_loading';

-- COMMAND ----------

-- drop table if exists dev_core_zone.mdl.meter_granular_hourly_billing_loading;
CREATE TABLE if not exists dev_core_zone.mdl.meter_granular_hourly_billing_loading
(
run_id string,
`id` bigint generated always as identity, 
service_point_id string,
interval_reading_date date,
interval_reading_hour integer,
kwh_delivered double,
kwh_received double,
kwh_net double,
kvarh_delivered double,
kvarh_received double,
kvarh_net double,
kw_delivered double,
kw_received double,
kw_net double ,
kvar_delivered double,
kvar_received double,
kvar_net double ,
kva_delivered double ,
kva_received double ,
kva_net double ,
pf_delivered double ,
pf_received double,
created_date date 
 )
 PARTITIONED BY (interval_reading_date, interval_reading_hour)
 LOCATION 's3a://ndl-us-east-1-s3-xe-dbxext/core/meter_granular_hourly_billing_loading';

-- COMMAND ----------

-- drop table dev_core_zone.mdl.last_ingestion_config;
CREATE TABLE if not exists dev_core_zone.mdl.last_ingestion_config
(`id` BIGINT generated always as identity,
run_id string,
table_name STRING,
max_id BIGINT,
created_at timestamp)
location 's3a://ndl-us-east-1-s3-xe-dbxext/core/last_ingestion_config';

-- COMMAND ----------

CREATE TABLE if not exists dev_core_zone.mdl.meter_granular_hourly_agg_billing_loading
(
run_id string,
`id` bigint generated always as identity, 
service_point_id string,
interval_reading_date date,
interval_reading_hour integer,
kwh_delivered_min double,
kwh_delivered_max double,
kwh_delivered_rms double,
kwh_received_min double,
kwh_received_max double,
kwh_received_rms double,
kwh_net_min double,
kwh_net_max double,
kwh_net_rms double,
kvarh_delivered_min double,
kvarh_delivered_max double,
kvarh_delivered_rms double,
kvarh_received_min double,
kvarh_received_max double,
kvarh_received_rms double,
kvarh_net_min double,
kvarh_net_max double,
kvarh_net_rms double,
kw_delivered_min double,
kw_delivered_max double,
kw_delivered_rms double,
kw_received_min double,
kw_received_max double,
kw_received_rms double,
kw_net_min double ,
kw_net_max double ,
kw_net_rms double ,
kvar_delivered_min double,
kvar_delivered_max double,
kvar_delivered_rms double,
kvar_received_min double,
kvar_received_max double,
kvar_received_rms double,
kvar_net_min double ,
kvar_net_max double ,
kvar_net_rms double ,
kva_delivered_min double ,
kva_delivered_max double ,
kva_delivered_rms double ,
kva_received_min double ,
kva_received_max double ,
kva_received_rms double ,
kva_net_min double ,
kva_net_max double ,
kva_net_rms double ,
pf_delivered_min double ,
pf_delivered_max double ,
pf_delivered_rms double ,
pf_received_min double,
pf_received_max double,
pf_received_rms double,
created_date date 
 )
 PARTITIONED BY (interval_reading_date, interval_reading_hour)
 LOCATION 's3a://ndl-us-east-1-s3-xe-dbxext/core/meter_granular_hourly_agg_billing_loading';
