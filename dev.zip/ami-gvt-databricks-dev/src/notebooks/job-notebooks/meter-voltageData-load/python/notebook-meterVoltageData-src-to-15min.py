# Databricks notebook source
# MAGIC %run ./common-etl-functions-notebook

# COMMAND ----------

from pyspark.sql.functions import * 
from pyspark.sql.types import *
from datetime import datetime
import time
from pyspark.sql import functions as func
import json
import logging
import boto3

# COMMAND ----------

if __name__ == "__main__":
    logging.basicConfig()
    logger = logging.getLogger("Meter_Data_Raw")
    logger.setLevel(logging.INFO)
    try:
        config_loc = dbutils.widgets.get("config_loc")
        env = dbutils.widgets.get("env")
        env_id = dbutils.widgets.get("env_id")
        meter_voltage_src = dbutils.widgets.get("meter_voltage_src")
        meter_granular_15_min_voltage_loading = dbutils.widgets.get("meter_granular_15_min_voltage_loading")
        last_ingestion_config = dbutils.widgets.get("last_ingestion_config_table")
        meter_voltage_hourly_gran_table = dbutils.widgets.get("meter_voltage_hourly_gran_table")
        config_loc = config_loc.format(env_id)
        dict_job_run_metadata = json.loads(dbutils.notebook.entry_point.getDbutils().notebook().getContext().toJson())
        currentRunId = str(dict_job_run_metadata['currentRunId']['id'])
        logger.info(f"{datetime.now()}: Run id - {currentRunId}")
        
        # config_json = lc(spark).read_config(config_loc)
        config_json = DataLoadFunctions(spark).read_config(config_loc)
        logger.info(f"{datetime.now()}: Fetched configuration from - {config_loc}")
        core_catalog = config_json['tiers']['core']['catalog'].format(env)
        core_schema = config_json['tiers']['core']['schema']

        # getting max_id from prim table before ingestion. This value will the stored in last_ingestion_config table 
        query_1 = f"""select max_id from {core_catalog}.{core_schema}.{last_ingestion_config} 
        where table_name = '{meter_voltage_src}'
        order by id desc"""
        id_from_src = spark.sql(query_1).collect()[0][0]
        logger.info(f"{datetime.now()}: max id before ingestion - {id_from_src}")
        # reading incremental data from prim table 
        time_format = "yyyy-MM-dd'T'HH:mm:ss.SSSz"
        query_2 = f""" 
        SELECT
          service_point_id,
          FROM_UNIXTIME(ROUND(UNIX_TIMESTAMP(end_time) / (15 * 60)) * (15 * 60)) AS interval_ts
          ,  MIN(value) AS min_voltage,
          MAX(value) AS max_voltage,
          AVG(value) AS avg_voltage
          FROM
          {core_catalog}.{core_schema}.{meter_voltage_src} 
        GROUP BY
          service_point_id,
        interval_ts
        ORDER BY
          interval_ts
        """
        prim_df = spark.sql(query_2).withColumn('created_date', current_date()).persist()
        prim_df.printSchema()
 

        prim_df = prim_df.withColumn('interval_ts', to_timestamp(prim_df['interval_ts']))

        # timestamp interval_ts from string
        prim_df.write.format('delta')\
                        .mode('append')\
                        .saveAsTable(f'{core_catalog}.{core_schema}.{meter_granular_15_min_voltage_loading}')
        prim_df.unpersist()
    except Exception as err:
        raise Exception("Error in running job: " + err.__str__())

