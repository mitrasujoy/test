# Databricks notebook source


# COMMAND ----------


# MAGIC %sql
# MAGIC CREATE TABLE if not exists dev_landing_zone.mdl.meter_voltage_raw
# MAGIC ( run_id string,
# MAGIC `id` bigint generated always as identity, 
# MAGIC   read_quality string,
# MAGIC   uom string,
# MAGIC  block_end_value bigint,
# MAGIC  raw_value bigint,
# MAGIC  value bigint,
# MAGIC  channel_number bigint,
# MAGIC  gateway_collected_time TIMESTAMP,
# MAGIC  end_time TIMESTAMP,
# MAGIC  service_point_id string,
# MAGIC  interval_length bigint,
# MAGIC  source_system string,
# MAGIC  created_at TIMESTAMP
# MAGIC  )
# MAGIC  PARTITIONED BY (channel_number)
# MAGIC  LOCATION 's3a://ndl-us-east-1-s3-xe-dbxext/land/meter_voltage_raw_landing_tbl';

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE if not exists dev_core_zone.mdl.meter_voltage_src
# MAGIC (
# MAGIC run_id string,
# MAGIC `id` bigint generated always as identity, 
# MAGIC   read_quality string,
# MAGIC   uom string,
# MAGIC  block_end_value bigint,
# MAGIC  raw_value bigint,
# MAGIC  value bigint,
# MAGIC  channel_number bigint,
# MAGIC  gateway_collected_time TIMESTAMP,
# MAGIC  end_time TIMESTAMP,
# MAGIC  service_point_id string,
# MAGIC  interval_length bigint,
# MAGIC  source_system string,
# MAGIC  created_at TIMESTAMP
# MAGIC
# MAGIC  )PARTITIONED BY (channel_number)
# MAGIC  LOCATION 's3a://ndl-us-east-1-s3-xe-dbxext/core/meter_voltage_src_tbl';

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE if not exists dev_core_zone.mdl.meter_granular_15_min_voltage_loading
# MAGIC ( 
# MAGIC   service_point_id string,
# MAGIC  interval_ts timestamp,
# MAGIC  min_voltage bigint,
# MAGIC  max_voltage bigint,
# MAGIC  avg_voltage double,
# MAGIC  created_date date
# MAGIC  )
# MAGIC  LOCATION 's3a://ndl-us-east-1-s3-xe-dbxext/core/meter_granular_15_min_voltage_loading';



# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE if not exists dev_core_zone.mdl.meter_granular_60_min_voltage_loading
# MAGIC ( 
# MAGIC   service_point_id string,
# MAGIC  interval_ts timestamp,
# MAGIC  min_voltage bigint,
# MAGIC  max_voltage bigint,
# MAGIC  avg_voltage double,
# MAGIC  created_date date
# MAGIC  )
# MAGIC  LOCATION 's3a://ndl-us-east-1-s3-xe-dbxext/core/meter_granular_60_min_voltage_loading';



# COMMAND ----------
