# Databricks notebook source
# dbutils.widgets.text("config_location", defaultValue="s3://ndl-us-east-1-s3-xe-rawdata/config/gis_data_config.json")
dbutils.widgets.text("config_location", defaultValue="")

# COMMAND ----------

from pyspark.sql.functions import * 
from pyspark.sql.types import *
from datetime import datetime
import time
from pyspark.sql import functions as func
import json
import logging

# COMMAND ----------

# MAGIC %run ./notebook-commonFunctions

# COMMAND ----------

config_loc = dbutils.widgets.get("config_location")

# COMMAND ----------

logging.basicConfig()
logger = logging.getLogger("mdl_gis_transformer_relation")
logger.setLevel(logging.INFO)
logger.info(f"{datetime.now()}: Run started")
logger.info("config_loc = " + config_loc)

try:
    job_func = JobFunctions(spark, config_loc)
    config_json = job_func.read_config()
    logger.debug(config_json)

    env = config_json["env"]
    gis_land_premise_address = config_json["tables"]["gis"]["gis_land_premise_address"]
    gis_land_lot_centroid_relationship = config_json["tables"]["gis"]["gis_land_lot_centroid_relationship"]
    gis_edist_oh_transformer_bank = config_json["tables"]["gis"]["gis_edist_oh_transformer_bank"]
    gis_edist_device_feeder = config_json["tables"]["gis"]["gis_edist_device_feeder"]
    gis_edist_circuit = config_json["tables"]["gis"]["gis_edist_circuit"]
    gis_edist_circuit_breaker = config_json["tables"]["gis"]["gis_edist_circuit_breaker"]
    gis_esub_substation = config_json["tables"]["gis"]["gis_esub_substation"]
    relation_table = config_json["tables"]["gvt"]["gis_transformer_relation"]["name"]
    relation_table_path = config_json["tables"]["gvt"]["gis_transformer_relation"]["path"]

    landing_catalog = config_json["tiers"]["land"]["catalog"].format(env)
    landing_schema = config_json["tiers"]["land"]["schema"]
    core_catalog = config_json["tiers"]["core"]["catalog"].format(env)
    core_schema = config_json["tiers"]["core"]["schema"]
    logger.info(f"{datetime.now()}: Variables are initialized")
except Exception as err:
    raise Exception("Error getting configuration parameters: " + err.__str__())

# COMMAND ----------

try:
    df = spark.sql(f"""select concat(lpa.PREMISE_ID, concat('_', concat(lpa.UTIL_TYPE, concat('_', lpa.SERVICENUM)))) AS service_point_id,
    lpa.PREMISE_ID as premise_id,
    llcr.LAND_LOT_CENTROID_ID as centroid_id,
    eotb.XCEL_ENERGY_DEVICE_ID AS transformer_id,
    ec.FEEDER_NO AS feeder_no,
    es.NAME AS substation_name,
    es.OPERATING_REGION AS opco,
    lpa.PREMISE_COUNT as premise_count,
    eotb.BANK_SIZE as bank_size,
    eotb.BANK_CONFIGURATION as bank_configuration,
    eotb.PHASE_DESIGNATION as phase_designation,
    eotb.XCEL_ENERGY_FIELD_STENCIL as field_stencil,
    eotb.OUTPUT_VOLTAGE as output_voltage,
    eotb.RATED_VOLTAGE as rated_voltage,
    current_timestamp() as created_timestamp
    FROM {landing_catalog}.{landing_schema}.{gis_land_premise_address} lpa
    JOIN {landing_catalog}.{landing_schema}.{gis_land_lot_centroid_relationship} llcr ON LLCR.LAND_LOT_CENTROID_ID = lpa.LAND_LOT_CENTROID_ID
    JOIN {landing_catalog}.{landing_schema}.{gis_edist_oh_transformer_bank} eotb ON llcr.RWO_OBJECT_ID = eotb.ID
    JOIN {landing_catalog}.{landing_schema}.{gis_edist_device_feeder} edf ON eotb.ID = edf.device_id
    JOIN {landing_catalog}.{landing_schema}.{gis_edist_circuit} ec ON edf.EDIST_CIRCUIT_FEEDER_NO = ec.FEEDER_NO
    LEFT JOIN {landing_catalog}.{landing_schema}.{gis_edist_circuit_breaker} ecb ON ec.ID = ecb.edist_circuit_id
    LEFT JOIN {landing_catalog}.{landing_schema}.{gis_esub_substation} es ON ecb.ESUB_SUBSTATION_ID = es.id
    where llcr.RWO_TABLE_ID = 'edist_oh_transformer_bank'""")
    # display(df)
    df.write.option("path", relation_table_path).option("mergeSchema", True).saveAsTable(f"{core_catalog}.{core_schema}.{relation_table}", format="delta", mode="overwrite")
except Exception as err:
    raise Exception("Error running Spark job: " + err.__str__())

# COMMAND ----------

# %sql
# drop table dev_core_zone.mdl.gis_transformer_relation;

# COMMAND ----------

# %sql
# select * from dev_core_zone.mdl.gis_transformer_relation where transformer_id is null;

# COMMAND ----------

# %sql
# select concat(lpa.PREMISE_ID, concat('_', concat(lpa.UTIL_TYPE, concat('_', lpa.SERVICENUM)))) AS service_point_id,
# lpa.PREMISE_ID as premise_id,
# llcr.LAND_LOT_CENTROID_ID as centroid_id,
# eotb.XCEL_ENERGY_DEVICE_ID AS transformer_id,
# ec.FEEDER_NO AS feeder_no,
# es.NAME AS substation_name,
# es.OPERATING_REGION AS opco,
# lpa.PREMISE_COUNT as premise_count,
# eotb.BANK_SIZE as bank_size,
# eotb.BANK_CONFIGURATION as bank_configuration,
# eotb.PHASE_DESIGNATION as phase_designation,
# eotb.XCEL_ENERGY_FIELD_STENCIL as field_stencil,
# eotb.OUTPUT_VOLTAGE as output_voltage,
# eotb.RATED_VOLTAGE as rated_voltage,
# current_timestamp() as created_timestamp
# FROM dev_landing_zone.mdl.gis_land_premise_address lpa
# JOIN dev_landing_zone.mdl.gis_land_lot_centroid_relationship llcr ON LLCR.LAND_LOT_CENTROID_ID = lpa.LAND_LOT_CENTROID_ID
# JOIN dev_landing_zone.mdl.gis_edist_oh_transformer_bank eotb ON llcr.RWO_OBJECT_ID = eotb.ID
# JOIN dev_landing_zone.mdl.gis_edist_device_feeder edf ON eotb.ID = edf.device_id
# JOIN dev_landing_zone.mdl.gis_edist_circuit ec ON edf.EDIST_CIRCUIT_FEEDER_NO = ec.FEEDER_NO
# LEFT JOIN dev_landing_zone.mdl.gis_edist_circuit_breaker ecb ON ec.ID = ecb.edist_circuit_id
# LEFT JOIN dev_landing_zone.mdl.gis_esub_substation es ON ecb.ESUB_SUBSTATION_ID = es.id
# where llcr.RWO_TABLE_ID = 'edist_oh_transformer_bank'
